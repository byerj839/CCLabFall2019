fruitData = {
    "apples": [
        1, 7, 3
    ],
    "pears": [
        1, 7, 3
    ],
    "oranges": [
        1, 7, 3
    ],
}

fruitData.apples[0];


//OR

fruitData = [{
        fruit: 'apples',
        price: 5
    },
    {
        fruit: 'pears',
        price: 10
    },
    {
        fruit: 'oranges',
        price: 8
    },
]


fruitData[0].price;